package br.senai.sc.reservaDeAmbientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservaDeAmbientesApplicationTests {

	@Test
	void contextLoads() {
	}

}

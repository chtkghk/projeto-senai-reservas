package br.senai.sc.reservaDeAmbientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservaDeAmbientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservaDeAmbientesApplication.class, args);
	}

}
